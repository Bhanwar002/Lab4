function square(num) {
    function multiply(num) {
        return num * num;
    }
    return multiply;
}